g++ -std=c++17 2105095.cpp
./a.out