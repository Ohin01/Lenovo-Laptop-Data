#include <iostream>
#include <cstdio>
#include <vector>
#include <unordered_map>
#include <pthread.h>
#include <semaphore.h>
#include <queue>
#include <time.h>
#include <unistd.h>
#include <random>
#include <chrono>
using namespace std::chrono;

using namespace std;



int get_random_number() {
    std::random_device rd;
    std::mt19937 generator(rd());
  
    double lambda = 2;
    std::poisson_distribution<int> poissonDist(lambda);
  
    return poissonDist(generator);

}

# define NUM_STATIONS 4

class Operative{
public:    
    int ID;
    int grpID;
    int stationID;
    int arrivalTime;
    bool isLeader;
    int docRecreationTime;
    int done;

};

class Staff{
    public:    
        int ID;
};


int N, M, x, y;
int currentTime=0;
int readerCount=0;
int totalSub=0;
int totalGrps=0;

pthread_t* threads;
pthread_mutex_t time_mutex;
pthread_mutex_t print_mutex;
pthread_mutex_t reader_writer_mutex;
//pthread_mutex_t station_mutex[NUM_STATIONS];
sem_t station_sem[NUM_STATIONS];
sem_t logbook_entry_sem;

//unordered_map<int,Operative*> operativesMap;



void* read_write_func(void* st){
    Staff* staff=(Staff*)st;
    int id=staff->ID;
    while(1){
        sleep(get_random_number());

        pthread_mutex_lock(&reader_writer_mutex);
        readerCount++;
        if(readerCount==1){
            sem_wait(&logbook_entry_sem);
        }

        pthread_mutex_unlock(&reader_writer_mutex);

        pthread_mutex_lock(&print_mutex);
        cout<<"Staff "<<staff->ID<<" began reviewing logbook at time "<<currentTime<<" Operations completed = "<<totalSub<<endl;
        pthread_mutex_unlock(&print_mutex);

        sleep(get_random_number());

        pthread_mutex_lock(&print_mutex);
        cout<<"Staff "<<staff->ID<<" finished reviewing logbook at time "<<currentTime<<endl;
        pthread_mutex_unlock(&print_mutex);

        pthread_mutex_lock(&reader_writer_mutex);
        readerCount--;
        if(readerCount==0){
            sem_post(&logbook_entry_sem);
        }
        pthread_mutex_unlock(&reader_writer_mutex);

        if(totalSub==totalGrps)break;
        

    }

    return NULL;

}

void* timer_func(void* arg)
{
    auto start = steady_clock::now();
    while (true)
    {
        sleep(1);

        auto now = steady_clock::now();
        auto elapsed = duration_cast<seconds>(now - start).count();

        pthread_mutex_lock(&time_mutex);
        currentTime = elapsed;
        pthread_mutex_unlock(&time_mutex);

    }

    return NULL;
}


void task2(Operative* op){

    sem_wait(&logbook_entry_sem);

    pthread_mutex_lock(&print_mutex);
    cout<<"Unit "<<op->grpID<<" has started writing at time "<<currentTime<<endl;
    pthread_mutex_unlock(&print_mutex);

    sleep(y);

    
    pthread_mutex_lock(&print_mutex);
    cout<<"Unit "<<op->grpID<<" has completed intelligence distribution at time "<<currentTime<<endl;
    pthread_mutex_unlock(&print_mutex);
    totalSub++;

    sem_post(&logbook_entry_sem);

}

void* task1(void* arg){
    Operative* op = (Operative*)arg;
    int station = op->stationID -1;
    int ran=get_random_number();
    //cout<<ran<<endl;
    sleep(ran);

    //cout<<"after sleeping"<<endl;
    pthread_mutex_lock(&print_mutex);
    op->arrivalTime=currentTime;
    pthread_mutex_unlock(&print_mutex);


    pthread_mutex_lock(&print_mutex);
    cout<<"Operative "<<op->ID<<" has arrived at typewriting station "<<op->stationID<< " at time "<<op->arrivalTime<<endl;
    pthread_mutex_unlock(&print_mutex);


    sem_wait(&station_sem[station]);
    
  
    pthread_mutex_lock(&print_mutex);
    cout<<"Operative "<<op->ID<<" has began writing at station "<<op->stationID<< " at time "<<currentTime<<endl;
    pthread_mutex_unlock(&print_mutex);

    sleep(x);

    pthread_mutex_lock(&print_mutex);
    cout<<"Operative "<<op->ID<<" has completed document recreation at time "<<currentTime<<endl;
    pthread_mutex_unlock(&print_mutex);


    sem_post(&station_sem[station]);

    if(!op->isLeader){
        return NULL;
    }

    for(int i = (op->grpID - 1)*M+1; i <= op->grpID*M; i++){
        if (i != op->ID)
        pthread_join(threads[i-1],NULL);
    }

    pthread_mutex_lock(&print_mutex);
    cout<<"Unit "<<op->grpID<<" has completed document recreation phase at time "<<currentTime<<endl;
    pthread_mutex_unlock(&print_mutex);

    //sleep(get_random_number());
    task2(op);

    return NULL;

}



int main(int argc, char *argv[]){

    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cin >> N >> M >> x >> y;

    totalGrps = N/M;

    sem_init(&logbook_entry_sem,0,1);
    pthread_mutex_init(&print_mutex, 0);
    pthread_mutex_init(&reader_writer_mutex, 0);


    pthread_t timer,staff1_thread,staff2_thread;
    pthread_create(&timer,NULL,timer_func,NULL);
    Staff staff1={1};
    Staff staff2={2};
    pthread_create(&staff1_thread,NULL,read_write_func,&staff1);
    pthread_create(&staff2_thread,NULL,read_write_func,&staff2);

    for(int i=0;i<NUM_STATIONS;i++){
        sem_init(&station_sem[i],0,1);
    }


    threads = new pthread_t[N];

    for(int i=1;i<=N;i++){
        Operative* operative= new Operative();
        operative->ID=i;
        operative->grpID=(i-1)/M+1;
        operative->stationID=(i%NUM_STATIONS)+1;
        operative->docRecreationTime=x;
        operative->done=0;
        operative->isLeader=((operative->grpID*M)==operative->ID);

        pthread_create(&threads[i-1],NULL,task1,(void*)operative);

    }

    for(int i=0;i<N;i++){
        if((i+1)%M==0){
            pthread_join(threads[i],NULL);
        }
        
    }

    
    // for (int i = 0; i < N; i++) {
    //     sem_destroy(&operative_sem[i]);
    //        delete operativesMap[i + 1];
    // }
    // sem_destroy(&lockTPS);

    delete[] threads;


    return 0;


}


